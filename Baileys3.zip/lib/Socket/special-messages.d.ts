import { proto } from '../../WAProto/index.js';
import type { WAMessage } from '../Types/index.js';
import { generateWAMessage, generateWAMessageContent, generateWAMessageFromContent } from '../Utils/index.js';
type UploadFn = any;
type UtilsLike = {
    generateWAMessageContent: typeof generateWAMessageContent;
    generateWAMessageFromContent: typeof generateWAMessageFromContent;
    generateWAMessage: typeof generateWAMessage;
    generateMessageID: () => string;
};
export type SpecialMessageType = 'PAYMENT' | 'PRODUCT' | 'ALBUM' | 'EVENT' | 'POLL_RESULT' | 'ORDER' | 'GROUP_STATUS' | 'GROUP_LABEL';
export declare class SpecialMessageHandler {
    private utils;
    private waUploadToServer;
    private relayMessage;
    private userJid;
    constructor(utils: UtilsLike, waUploadToServer: UploadFn, relayMessage: (jid: string, content: proto.IMessage, options: any) => Promise<string>, userJid: string);
    detectType(content: any): SpecialMessageType | null;
    private opts;
    handlePayment(content: any, quoted?: any): Promise<{
        requestPaymentMessage: proto.Message.RequestPaymentMessage;
    }>;
    handleProduct(content: any, _jid: string, _quoted?: any): Promise<{
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: any;
                    };
                    footer: {
                        text: any;
                    };
                    header: {
                        title: any;
                        hasMediaAttachment: boolean;
                        productMessage: {
                            product: {
                                productImage: any;
                                productId: any;
                                title: any;
                                description: any;
                                currencyCode: any;
                                priceAmount1000: any;
                                retailerId: any;
                                url: any;
                                productImageCount: number;
                            };
                            businessOwnerJid: string;
                        };
                    };
                    nativeFlowMessage: {
                        buttons: any;
                    };
                };
            };
        };
    }>;
    handleAlbum(content: any, jid: string, quoted?: any): Promise<WAMessage>;
    handleEvent(content: any, jid: string, quoted?: any): Promise<WAMessage>;
    handlePollResult(content: any, jid: string, quoted?: any): Promise<WAMessage>;
    handleOrderMessage(content: any, jid: string, quoted?: any): Promise<WAMessage>;
    handleGroupStory(content: any, jid: string, _quoted?: any): Promise<string>;
    handleGbLabel(content: any, jid: string): Promise<WAMessage>;
    /** Process special content if detected; returns the WAMessage / result or null if not special */
    process(jid: string, content: any, options?: {
        quoted?: any;
    }): Promise<WAMessage | any | null>;
}
export {};
//# sourceMappingURL=special-messages.d.ts.map
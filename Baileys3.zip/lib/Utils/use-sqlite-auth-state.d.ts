import type { AuthenticationState } from '../Types/index.js';
export type UseSqliteAuthStateOptions = {
    /** file name for the database, used when `pathOrFolder` is a folder. Default: `auth.db` */
    fileName?: string;
    /** legacy `useMultiFileAuthState` folder to migrate from, if the DB has no creds yet */
    migrateFromFolder?: string;
    logger?: any;
};
/**
 * Stores the full authentication state in a single SQLite database file, using Node's
 * built-in `node:sqlite` module (requires Node 22.5+).
 *
 * Ported from the `@vansnowi/baileys` fork.
 *
 * @param pathOrFolder either a full path to the `.db`/`.sqlite`/`.sqlite3` file, or a folder
 * (in which case `fileName` is appended to it)
 */
export declare const useSqliteAuthState: (pathOrFolder: string, options?: UseSqliteAuthStateOptions) => Promise<{
    state: AuthenticationState;
    saveCreds: () => Promise<void>;
    db: any;
    close: () => void;
}>;
//# sourceMappingURL=use-sqlite-auth-state.d.ts.map
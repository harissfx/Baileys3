/**
 * Meta AI reply helpers: wait for a (streamed) reply from the Meta AI bot,
 * collect image URLs / media from richResponseMessage + unifiedResponse,
 * and download generated images.
 *
 * Usage:
 *   const waiting = waitForMetaAiReply(sock, { timeoutMs: 90_000 })
 *   await sock.sendMetaAI('hello')
 *   const reply = await waiting   // { text, images, unified, raw }
 */
import type { proto } from '../../WAProto/index.js';
import type { BaileysEventEmitter, WAMessage } from '../Types/index.js';
export declare const META_AI_BOT_JID = "867051314767696@bot";
export declare const META_AI_REPLY_TIMEOUT_MS = 90000;
export type MetaAiReply = {
    /** Reply text (may still contain internal `container:///` image refs, see cleanMetaAiText) */
    text: string;
    /** Image URLs found in the rich response */
    images: string[];
    /** Decoded unifiedResponse payload, if any */
    unified: any | null;
    /** Last raw message that updated this reply */
    raw: WAMessage;
};
export type WaitForMetaAiReplyOptions = {
    /** Reject if nothing arrives within this time. Default 90s */
    timeoutMs?: number;
    /** Resolve once no new update arrived for this long. Default 3s */
    settleMs?: number;
};
export type MetaAiMediaItem = {
    url: string;
    mime_type: string;
    [key: string]: any;
};
export type MetaAiImage = {
    buffer: Buffer;
    mimetype: 'image/jpeg' | 'image/png' | 'image/webp';
};
/** Collect image URLs from a richResponseMessage (grid/inline images + scan of unifiedResponse). */
export declare const getMetaAiImageUrls: (message: proto.IMessage | null | undefined) => string[];
/** Find image media objects (`{ url, mime_type: image/* }`) inside a unifiedResponse payload. */
export declare const getMetaAiMediaItems: (root: any) => MetaAiMediaItem[];
/**
 * Download a Meta AI image straight from `media.url`.
 * WebP is converted to JPEG when `sharp` is installed, otherwise returned as-is.
 */
export declare const fetchMetaAiImage: (item: Pick<MetaAiMediaItem, "url">) => Promise<MetaAiImage>;
/** Strip internal Meta AI image refs (`![..](container:///..)`) that are not openable URLs. */
export declare const cleanMetaAiText: (text?: string | null) => string;
/**
 * Wait for the Meta AI reply (msmsg / MESSAGE_EDIT streaming).
 * The answer arrives in chunks, so the result is resolved once no new update
 * arrived for `settleMs`. Call this BEFORE `sock.sendMetaAI(...)`.
 */
export declare const waitForMetaAiReply: (sock: {
    ev: BaileysEventEmitter;
}, { timeoutMs, settleMs }?: WaitForMetaAiReplyOptions) => Promise<MetaAiReply>;
//# sourceMappingURL=meta-ai-reply.d.ts.map
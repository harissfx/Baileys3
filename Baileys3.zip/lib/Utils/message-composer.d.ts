import { proto } from '../../WAProto/index.js';
declare const JS_KEYWORDS: Set<string>;
declare const PYTHON_KEYWORDS: Set<string>;
declare const LANGUAGE_KEYWORDS: Record<string, Set<string>>;
export declare enum CodeHighlightType {
    DEFAULT = 0,
    KEYWORD = 1,
    METHOD = 2,
    STRING = 3,
    NUMBER = 4,
    COMMENT = 5
}
export declare enum RichSubMessageType {
    UNKNOWN = 0,
    GRID_IMAGE = 1,
    TEXT = 2,
    INLINE_IMAGE = 3,
    TABLE = 4,
    CODE = 5,
    DYNAMIC = 6,
    MAP = 7,
    LATEX = 8,
    CONTENT_ITEMS = 9
}
export type CodeBlock = {
    highlightType: CodeHighlightType;
    codeContent: string;
};
/**
 * Tokenize source code into highlighted blocks for rich code messages.
 */
export declare const tokenizeCode: (codeStr: string, language?: string) => CodeBlock[];
export declare const buildRichContextInfo: (quoted?: any, options?: {
    botJid?: string;
    mentions?: string[];
}) => any;
export declare const buildBotForwardedMessage: (submessages: any[], contextInfo: any, unifiedResponse?: any) => proto.IMessage;
export declare const generateTableContent: (title: string, headers: string[], rows: string[][], quoted?: any, options?: any) => {
    message: proto.IMessage;
    messageId: string;
};
export declare const generateListContent: (title: string, items: string[], quoted?: any, options?: any) => {
    message: proto.IMessage;
    messageId: string;
};
export declare const generateCodeBlockContent: (code: string, quoted?: any, options?: {
    language?: string;
    title?: string;
    footer?: string;
    botJid?: string;
    mentions?: string[];
}) => {
    message: proto.IMessage;
    messageId: string;
};
export declare const generateLatexContent: (quoted?: any, options?: any) => {
    message: proto.IMessage;
    messageId: string;
};
export declare const generateLatexImageContent: (quoted: any, options: any, uploadFn: (buffer: Buffer, type: string) => Promise<any>, renderLatexToPng: (expr: string) => Promise<{
    buffer: Buffer;
    width: number;
    height: number;
}>) => Promise<{
    message: proto.IMessage;
    messageId: string;
}>;
export declare const generateLatexInlineImageContent: (quoted: any, options: any, uploadFn: (buffer: Buffer, type: string) => Promise<any>, renderLatexToPng: (expr: string) => Promise<{
    buffer: Buffer;
    width: number;
    height: number;
}>) => Promise<{
    message: proto.IMessage;
    messageId: string;
}>;
export declare const captureUnifiedResponse: (msg: any) => {
    unifiedResponse: {
        data: any;
    };
    submessages: any;
    contextInfo: any;
} | null;
export declare const generateUnifiedResponseContent: (quoted: any, captured: any) => {
    message: proto.IMessage;
    messageId: string;
};
export declare const generateRichMessageContent: (submessages: any[], quoted?: any, options?: any) => {
    message: proto.IMessage;
    messageId: string;
};
export { JS_KEYWORDS, PYTHON_KEYWORDS, LANGUAGE_KEYWORDS };
//# sourceMappingURL=message-composer.d.ts.map
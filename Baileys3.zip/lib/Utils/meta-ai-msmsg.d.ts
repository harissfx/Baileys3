import { proto } from '../../WAProto/index.js';
/**
 * Decrypts <enc type="msmsg"> bot messages.
 *
 * Two-pass HKDF — algorithm from bot_message.rs (BotMessageContext):
 *   k1    = HKDF(messageSecret, salt=∅, info="Bot Message",                     32)
 *   k2    = HKDF(k1,            salt=∅, info=msgID||target_sender_jid||bot_jid, 32)
 *   AAD   = msgID || 0x00 || bot_user_jid
 *   plain = AES-256-GCM.Decrypt(k2, encIv, encPayload, AAD)
 */
export declare const decryptMsmsgBotMessage: (messageSecret: Uint8Array | Buffer, messageKey: {
    participant: string;
    meId: string;
    meLid?: string;
    botEditTargetId?: string | null;
    metaTargetId?: string | null;
    stanzaId?: string | null;
}, msMsg: {
    encIv?: Uint8Array | null;
    encPayload?: Uint8Array | null;
}) => Promise<Buffer>;
export declare const decodeDecryptedMsmsgMessage: (decrypted: Uint8Array | Buffer) => proto.IMessage;
export declare const parseUnifiedResponseData: (data: any) => any | null;
export declare const textFromUnifiedResponse: (data: any) => string | null;
export declare const textFromRichResponse: (rr: any) => string | null;
/**
 * Extract answer text from any Meta AI message body —
 * plain, protocolMessage/MESSAGE_EDIT streaming chunk, or richResponseMessage.
 */
export declare const extractMetaAiText: (message: proto.IMessage | null | undefined) => string | null;
/**
 * Decode unifiedResponse.data IN PLACE: keep raw `data`, attach `decodedData` + `text`.
 */
export declare const decodeUnifiedResponseInPlace: <T extends proto.IMessage | any>(message: T) => T;
//# sourceMappingURL=meta-ai-msmsg.d.ts.map
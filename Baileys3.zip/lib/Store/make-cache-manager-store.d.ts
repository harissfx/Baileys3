export default function makeCacheManagerAuthState(store: any, sessionKey: string): Promise<{
    state: {
        creds: any;
        keys: {
            get: (type: string, ids: string[]) => Promise<Record<string, any>>;
            set: (data: Record<string, any>) => Promise<void>;
        };
    };
    saveCreds: () => Promise<void>;
    clearState: () => Promise<void>;
}>;
//# sourceMappingURL=make-cache-manager-store.d.ts.map
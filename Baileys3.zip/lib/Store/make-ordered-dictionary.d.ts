export default function makeOrderedDictionary<T = any>(idGetter: (item: T) => string): {
    array: T[];
    get: (id: string) => T | undefined;
    update: (item: T) => boolean;
    upsert: (item: T, mode?: "append" | "prepend") => void;
    remove: (item: T) => boolean;
    updateAssign: (id: string, updateObj: Partial<T>) => boolean;
    clear: () => void;
    filter: (contain: (item: T) => boolean) => void;
    toJSON: () => T[];
    fromJSON: (newItems: T[]) => void;
};
//# sourceMappingURL=make-ordered-dictionary.d.ts.map
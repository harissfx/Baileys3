import { ObjectRepository } from './object-repository.js';
import KeyedDB from './keyed-db.js';
export declare const waMessageID: (m: any) => any;
export declare const waLabelAssociationKey: {
    key: (la: any) => any;
    compare: (k1: any, k2: any) => any;
};
export default function makeInMemoryStore(config: any): {
    chats: KeyedDB<any>;
    contacts: {};
    messages: {};
    groupMetadata: {};
    state: {
        connection: string;
    };
    presences: {};
    labels: ObjectRepository<any>;
    labelAssociations: KeyedDB<any>;
    bind: (ev: any) => void;
    toJSON: () => {
        chats: KeyedDB<any>;
        contacts: {};
        messages: {};
        labels: ObjectRepository<any>;
        labelAssociations: KeyedDB<any>;
    };
    fromJSON: (json: any) => void;
    loadMessage: (jid: any, id: any) => Promise<any>;
};
//# sourceMappingURL=make-in-memory-store.d.ts.map
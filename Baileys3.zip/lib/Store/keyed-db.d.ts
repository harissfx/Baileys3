type CompareFn = (a: string, b: string) => number;
type IdGetter<T> = (entry: T) => string;
export default class KeyedDB<T = any> {
    private _compare;
    private _idGetter;
    private _array;
    private _dict;
    constructor(compareFn: CompareFn, idGetter: IdGetter<T>);
    get length(): number;
    get(id: string): T | undefined;
    insert(entry: T, _mode?: string): boolean;
    insertIfAbsent(...entries: T[]): void;
    upsert(...entries: T[]): void;
    update(id: string, updater: (item: T) => void): boolean;
    updateAssign(id: string, update: Partial<T>): boolean;
    deleteById(id: string): boolean;
    /** alias used by make-in-memory-store */
    delete(entry: T | string): boolean;
    clear(): void;
    all(): T[];
    filter(predicate: (entry: T) => boolean): void;
    get count(): number;
    toJSON(): T[];
    fromJSON(array: T[]): void;
    [Symbol.iterator](): ArrayIterator<T>;
}
export {};
//# sourceMappingURL=keyed-db.d.ts.map
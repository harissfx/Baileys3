export declare class ObjectRepository<T = any> {
    private entityMap;
    constructor(entities?: Record<string, T>);
    findById(id: string): T | undefined;
    findAll(): T[];
    upsertById(id: string, entity: T): void;
    deleteById(id: string): boolean;
    get count(): number;
}
export default ObjectRepository;
//# sourceMappingURL=object-repository.d.ts.map
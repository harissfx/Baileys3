import NodeCache from '@cacheable/node-cache'
import { Boom } from '@hapi/boom'
import { randomBytes, randomUUID } from 'node:crypto'
import { proto } from '../../WAProto/index.js'
import { DEFAULT_CACHE_TTLS, WA_DEFAULT_EPHEMERAL } from '../Defaults/index.js'
import type {
	AnyMessageContent,
	MediaConnInfo,
	MessageReceiptType,
	MessageRelayOptions,
	MiscMessageGenerationOptions,
	RichMenuContent,
	SocketConfig,
	WAMessage,
	WAMessageKey
} from '../Types/index.js'
import {
	aggregateMessageKeysNotFromMe,
	assertMediaContent,
	assertMeId,
	bindWaitForEvent,
	decryptMediaRetryData,
	DEF_MEDIA_HOST,
	encodeNewsletterMessage,
	encodeSignedDeviceIdentity,
	encodeWAMessage,
	encryptMediaRetryRequest,
	extractDeviceJids,
	generateMessageIDV2,
	generateParticipantHashV2,
	generateWAMessage,
	generateWAMessageContent,
	generateWAMessageFromContent,
	getStatusCodeForMediaRetry,
	getUrlFromDirectPath,
	getWAUploadToServer,
	MessageRetryManager,
	normalizeMessageContent,
	parseAndInjectE2ESessions,
	unixTimestampSeconds
} from '../Utils/index.js'
import { getUrlInfo } from '../Utils/link-preview.js'
import { makeKeyedMutex, makeMutex } from '../Utils/make-mutex.js'
import { getMessageReportingToken, shouldIncludeReportingToken } from '../Utils/reporting-utils.js'
import {
	buildMergedTcTokenIndexWrite,
	isTcTokenExpired,
	resolveIssuanceJid,
	resolveTcTokenJid,
	shouldSendNewTcToken,
	storeTcTokensFromIqResult
} from '../Utils/tc-token-utils.js'
import { setBotMessageSecret } from '../Utils/decode-wa-message.js'
import { captureUnifiedResponse, generateUnifiedResponseContent } from '../Utils/message-composer.js'
import {
	areJidsSameUser,
	type BinaryNode,
	type BinaryNodeAttributes,
	type FullJid,
	getBinaryNodeChild,
	getBinaryNodeChildren,
	isHostedLidUser,
	isHostedPnUser,
	isJidBot,
	isJidGroup,
	isJidMetaAI,
	isLidUser,
	isPnUser,
	jidDecode,
	jidEncode,
	jidNormalizedUser,
	type JidWithDevice,
	PSA_WID,
	S_WHATSAPP_NET
} from '../WABinary/index.js'
import { USyncQuery, USyncUser } from '../WAUSync/index.js'
import { makeUsernameSocket } from './username.js'
import { SpecialMessageHandler } from './special-messages.js'

export const makeMessagesSocket = (config: SocketConfig) => {
	const {
		logger,
		linkPreviewImageThumbnailWidth,
		generateHighQualityLinkPreview,
		options: httpRequestOptions,
		patchMessageBeforeSending,
		cachedGroupMetadata,
		enableRecentMessageCache,
		maxMsgRetryCount
	} = config
	const sock = makeUsernameSocket(config)
	const {
		ev,
		authState,
		messageMutex,
		signalRepository,
		upsertMessage,
		query,
		fetchPrivacySettings,
		sendNode,
		groupMetadata,
		groupToggleEphemeral,
		registerSocketEndHandler
	} = sock

	const getLIDForPN = signalRepository.lidMapping.getLIDForPN.bind(signalRepository.lidMapping)

	/**
	 * Set of tctoken storage JIDs with a fire-and-forget `issuePrivacyTokens` IQ in flight.
	 * Prevents duplicate IQs from rapid back-to-back sends before `senderTimestamp` persists.
	 * Entries are always removed in `.finally()`, so the set is bounded by concurrency.
	 */
	const inFlightTcTokenIssuance = new Set<string>()

	const userDevicesCache =
		config.userDevicesCache ||
		new NodeCache<JidWithDevice[]>({
			stdTTL: DEFAULT_CACHE_TTLS.USER_DEVICES, // 5 minutes
			useClones: false
		})
	/** Serializes writes to userDevicesCache across USync refresh and device-notification handling. */
	const devicesMutex = makeMutex()

	// Initialize message retry manager if enabled
	const messageRetryManager = enableRecentMessageCache ? new MessageRetryManager(logger, maxMsgRetryCount) : null

	// Prevent race conditions in Signal session encryption by user
	const encryptionMutex = makeKeyedMutex()

	let mediaConn: Promise<MediaConnInfo> | undefined
	/** Per-socket media host; updated whenever media_conn is fetched. Defaults to the public WhatsApp host. */
	let mediaHost: string = DEF_MEDIA_HOST
	const refreshMediaConn = async (forceGet = false): Promise<MediaConnInfo> => {
		const media = await mediaConn
		if (!media || forceGet || new Date().getTime() - media.fetchDate.getTime() > media.ttl * 1000) {
			mediaConn = (async () => {
				const result = await query({
					tag: 'iq',
					attrs: {
						type: 'set',
						xmlns: 'w:m',
						to: S_WHATSAPP_NET
					},
					content: [{ tag: 'media_conn', attrs: {} }]
				})
				const mediaConnNode = getBinaryNodeChild(result, 'media_conn')!
				// TODO: explore full length of data that whatsapp provides
				const node: MediaConnInfo = {
					hosts: getBinaryNodeChildren(mediaConnNode, 'host').map(({ attrs }) => ({
						hostname: attrs.hostname!,
						maxContentLengthBytes: +attrs.maxContentLengthBytes!
					})),
					auth: mediaConnNode.attrs.auth!,
					ttl: +mediaConnNode.attrs.ttl!,
					fetchDate: new Date()
				}
				logger.debug('fetched media conn')
				if (node.hosts[0]) {
					mediaHost = node.hosts[0].hostname
				}

				return node
			})()
		}

		return mediaConn!
	}

	/**
	 * generic send receipt function
	 * used for receipts of phone call, read, delivery etc.
	 * */
	const sendReceipt = async (
		jid: string,
		participant: string | undefined,
		messageIds: string[],
		type: MessageReceiptType
	) => {
		if (!messageIds || messageIds.length === 0) {
			throw new Boom('missing ids in receipt')
		}

		const node: BinaryNode = {
			tag: 'receipt',
			attrs: {
				id: messageIds[0]!
			}
		}
		const isReadReceipt = type === 'read' || type === 'read-self'
		if (isReadReceipt) {
			node.attrs.t = unixTimestampSeconds().toString()
		}

		if (type === 'sender' && (isPnUser(jid) || isLidUser(jid))) {
			node.attrs.recipient = jid
			node.attrs.to = participant!
		} else {
			node.attrs.to = jid
			if (participant) {
				node.attrs.participant = participant
			}
		}

		if (type) {
			node.attrs.type = type
		}

		const remainingMessageIds = messageIds.slice(1)
		if (remainingMessageIds.length) {
			node.content = [
				{
					tag: 'list',
					attrs: {},
					content: remainingMessageIds.map(id => ({
						tag: 'item',
						attrs: { id }
					}))
				}
			]
		}

		logger.debug({ attrs: node.attrs, messageIds }, 'sending receipt for messages')
		await sendNode(node)
	}

	/** Correctly bulk send receipts to multiple chats, participants */
	const sendReceipts = async (keys: WAMessageKey[], type: MessageReceiptType) => {
		const recps = aggregateMessageKeysNotFromMe(keys)
		for (const { jid, participant, messageIds } of recps) {
			await sendReceipt(jid, participant, messageIds, type)
		}
	}

	/** Bulk read messages. Keys can be from different chats & participants */
	const readMessages = async (keys: WAMessageKey[]) => {
		const privacySettings = await fetchPrivacySettings()
		// based on privacy settings, we have to change the read type
		const readType = privacySettings.readreceipts === 'all' ? 'read' : 'read-self'
		await sendReceipts(keys, readType)
	}

	/** Device info with wire JID */
	type DeviceWithJid = JidWithDevice & {
		jid: string
	}

	/** Fetch all the devices we've to send a message to */
	const getUSyncDevices = async (
		jids: string[],
		useCache: boolean,
		ignoreZeroDevices: boolean
	): Promise<DeviceWithJid[]> => {
		const deviceResults: DeviceWithJid[] = []

		if (!useCache) {
			logger.debug('not using cache for devices')
		}

		const toFetch: string[] = []

		const jidsWithUser = jids
			.map(jid => {
				const decoded = jidDecode(jid)
				const user = decoded?.user
				const device = decoded?.device
				// Meta AI / bot (@bot): endpoint device 0 tunggal yang TIDAK dienumerasi usync.
				// Kalau diserahkan ke usync, hasilnya kosong dan bot terbuang dari penerima. Suntik langsung device 0.
				if (user && (isJidMetaAI(jid) || isJidBot(jid))) {
					deviceResults.push({ user, device: typeof device === 'number' ? device : 0, jid })
					return null
				}

				const isExplicitDevice = typeof device === 'number' && device >= 0

				if (isExplicitDevice && user) {
					deviceResults.push({
						user,
						device,
						jid
					})
					return null
				}

				jid = jidNormalizedUser(jid)
				return { jid, user }
			})
			.filter(jid => jid !== null)

		let mgetDevices: undefined | Record<string, FullJid[] | undefined>

		if (useCache && userDevicesCache.mget) {
			const usersToFetch = jidsWithUser.map(j => j?.user).filter(Boolean) as string[]
			mgetDevices = await userDevicesCache.mget(usersToFetch)
		}

		for (const { jid, user } of jidsWithUser) {
			if (useCache) {
				const devices =
					mgetDevices?.[user!] ||
					(userDevicesCache.mget ? undefined : ((await userDevicesCache.get(user!)) as FullJid[]))
				if (devices) {
					const devicesWithJid = devices.map(d => ({
						...d,
						jid: jidEncode(d.user, d.server, d.device)
					}))
					deviceResults.push(...devicesWithJid)

					logger.trace({ user }, 'using cache for devices')
				} else {
					toFetch.push(jid)
				}
			} else {
				toFetch.push(jid)
			}
		}

		if (!toFetch.length) {
			return deviceResults
		}

		const requestedLidUsers = new Set<string>()
		for (const jid of toFetch) {
			if (isLidUser(jid) || isHostedLidUser(jid)) {
				const user = jidDecode(jid)?.user
				if (user) requestedLidUsers.add(user)
			}
		}

		const query = new USyncQuery().withContext('message').withDeviceProtocol().withLIDProtocol()

		for (const jid of toFetch) {
			query.withUser(new USyncUser().withId(jid)) // todo: investigate - the idea here is that <user> should have an inline lid field with the lid being the pn equivalent
		}

		const result = await sock.executeUSyncQuery(query)

		if (result) {
			// TODO: LID MAP this stuff (lid protocol will now return lid with devices)
			const lidResults = result.list.filter(a => !!a.lid)
			if (lidResults.length > 0) {
				logger.trace('Storing LID maps from device call')
				await signalRepository.lidMapping.storeLIDPNMappings(lidResults.map(a => ({ lid: a.lid as string, pn: a.id })))

				// Force-refresh sessions for newly mapped LIDs to align identity addressing
				try {
					const lids = lidResults.map(a => a.lid as string)
					if (lids.length) {
						await assertSessions(lids, true)
					}
				} catch (e) {
					logger.warn({ e, count: lidResults.length }, 'failed to assert sessions for newly mapped LIDs')
				}
			}

			const extracted = extractDeviceJids(
				result?.list,
				authState.creds.me!.id,
				authState.creds.me!.lid!,
				ignoreZeroDevices
			)
			const deviceMap: { [_: string]: FullJid[] } = {}

			for (const item of extracted) {
				deviceMap[item.user] = deviceMap[item.user] || []
				deviceMap[item.user]?.push(item)
			}

			// Process each user's devices as a group for bulk LID migration
			for (const [user, userDevices] of Object.entries(deviceMap)) {
				const isLidUser = requestedLidUsers.has(user)

				// Process all devices for this user
				for (const item of userDevices) {
					const finalJid = isLidUser
						? jidEncode(user, item.server, item.device)
						: jidEncode(item.user, item.server, item.device)

					deviceResults.push({
						...item,
						jid: finalJid
					})

					logger.debug(
						{
							user: item.user,
							device: item.device,
							finalJid,
							usedLid: isLidUser
						},
						'Processed device with LID priority'
					)
				}
			}

			await devicesMutex.mutex(async () => {
				if (userDevicesCache.mset) {
					// if the cache supports mset, we can set all devices in one go
					await userDevicesCache.mset(Object.entries(deviceMap).map(([key, value]) => ({ key, value })))
				} else {
					for (const key in deviceMap) {
						if (deviceMap[key]) await userDevicesCache.set(key, deviceMap[key])
					}
				}
			})

			const userDeviceUpdates: { [userId: string]: string[] } = {}
			for (const [userId, devices] of Object.entries(deviceMap)) {
				if (devices && devices.length > 0) {
					userDeviceUpdates[userId] = devices.map(d => d.device?.toString() || '0')
				}
			}

			if (Object.keys(userDeviceUpdates).length > 0) {
				try {
					await authState.keys.set({ 'device-list': userDeviceUpdates })
					logger.debug(
						{ userCount: Object.keys(userDeviceUpdates).length },
						'stored user device lists for bulk migration'
					)
				} catch (error) {
					logger.warn({ error }, 'failed to store user device lists')
				}
			}
		}

		return deviceResults
	}

	/**
	 * Update Member Label
	 */
	const updateMemberLabel = (jid: string, memberLabel: string) => {
		return relayMessage(
			jid,
			{
				protocolMessage: {
					type: proto.Message.ProtocolMessage.Type.GROUP_MEMBER_LABEL_CHANGE,
					memberLabel: {
						label: memberLabel?.slice(0, 30),
						labelTimestamp: unixTimestampSeconds()
					}
				}
			},
			{
				additionalNodes: [
					{
						tag: 'meta',
						attrs: {
							tag_reason: 'user_update',
							appdata: 'member_tag'
						},
						content: undefined
					}
				]
			}
		)
	}

	const assertSessions = async (jids: string[], force?: boolean) => {
		let didFetchNewSession = false
		const uniqueJids = [...new Set(jids)]
		const jidsRequiringFetch: string[] = []

		logger.debug({ jids }, 'assertSessions call with jids')

		for (const jid of uniqueJids) {
			if (!force) {
				const sessionValidation = await signalRepository.validateSession(jid)
				if (sessionValidation.exists) {
					continue
				}
			}

			jidsRequiringFetch.push(jid)
		}

		if (jidsRequiringFetch.length) {
			// LID if mapped, otherwise original
			const wireJids = [
				...jidsRequiringFetch.filter(jid => !!isLidUser(jid) || !!isHostedLidUser(jid)),
				// Meta AI (@bot) harus ikut di-fetch prekey-nya, kalau tidak sesi ke bot tidak pernah terbentuk
				...jidsRequiringFetch.filter(jid => !!isJidMetaAI(jid) || !!isJidBot(jid)),
				...(
					(await signalRepository.lidMapping.getLIDsForPNs(
						jidsRequiringFetch.filter(jid => !!isPnUser(jid) || !!isHostedPnUser(jid))
					)) || []
				).map(a => a.lid)
			]

			logger.debug({ jidsRequiringFetch, wireJids }, 'fetching sessions')
			const result = await query({
				tag: 'iq',
				attrs: {
					xmlns: 'encrypt',
					type: 'get',
					to: S_WHATSAPP_NET
				},
				content: [
					{
						tag: 'key',
						attrs: {},
						content: wireJids.map(jid => {
							const attrs: { [key: string]: string } = { jid }
							if (force) attrs.reason = 'identity'
							return { tag: 'user', attrs }
						})
					}
				]
			})
			await parseAndInjectE2ESessions(result, signalRepository)
			didFetchNewSession = true
		}

		return didFetchNewSession
	}

	const sendPeerDataOperationMessage = async (
		pdoMessage: proto.Message.IPeerDataOperationRequestMessage
	): Promise<string> => {
		//TODO: for later, abstract the logic to send a Peer Message instead of just PDO - useful for App State Key Resync with phone
		if (!authState.creds.me?.id) {
			throw new Boom('Not authenticated')
		}

		const protocolMessage: proto.IMessage = {
			protocolMessage: {
				peerDataOperationRequestMessage: pdoMessage,
				type: proto.Message.ProtocolMessage.Type.PEER_DATA_OPERATION_REQUEST_MESSAGE
			}
		}

		const meJid = jidNormalizedUser(authState.creds.me.id)

		const msgId = await relayMessage(meJid, protocolMessage, {
			additionalAttributes: {
				category: 'peer',

				push_priority: 'high_force'
			},
			additionalNodes: [
				{
					tag: 'meta',
					attrs: { appdata: 'default' }
				}
			]
		})

		return msgId
	}

	const createParticipantNodes = async (
		recipientJids: string[],
		message: proto.IMessage,
		extraAttrs?: BinaryNode['attrs'],
		dsmMessage?: proto.IMessage
	) => {
		if (!recipientJids.length) {
			return { nodes: [] as BinaryNode[], shouldIncludeDeviceIdentity: false }
		}

		const patched = await patchMessageBeforeSending(message, recipientJids)
		const patchedMessages = Array.isArray(patched)
			? patched
			: recipientJids.map(jid => ({ recipientJid: jid, message: patched }))

		let shouldIncludeDeviceIdentity = false
		const meId = authState.creds.me!.id
		const meLid = authState.creds.me?.lid
		const meLidUser = meLid ? jidDecode(meLid)?.user : null

		const encryptionPromises = (patchedMessages as any).map(
			async ({ recipientJid: jid, message: patchedMessage }: any) => {
				try {
					if (!jid) return null

					let msgToEncrypt = patchedMessage

					if (dsmMessage) {
						const { user: targetUser } = jidDecode(jid)!
						const { user: ownPnUser } = jidDecode(meId)!
						const ownLidUser = meLidUser

						const isOwnUser = targetUser === ownPnUser || (ownLidUser && targetUser === ownLidUser)
						const isExactSenderDevice = jid === meId || (meLid && jid === meLid)

						if (isOwnUser && !isExactSenderDevice) {
							msgToEncrypt = dsmMessage
							logger.debug({ jid, targetUser }, 'Using DSM for own device')
						}
					}

					const bytes = encodeWAMessage(msgToEncrypt)
					const mutexKey = jid

					const node = await encryptionMutex.mutex(mutexKey, async () => {
						const { type, ciphertext } = await signalRepository.encryptMessage({ jid, data: bytes })

						if (type === 'pkmsg') {
							shouldIncludeDeviceIdentity = true
						}

						return {
							tag: 'to',
							attrs: { jid },
							content: [
								{
									tag: 'enc',
									attrs: { v: '2', type, ...(extraAttrs || {}) },
									content: ciphertext
								}
							]
						}
					})

					return node
				} catch (err) {
					logger.error({ jid, err }, 'Failed to encrypt for recipient')
					return null
				}
			}
		)

		const nodes = (await Promise.all(encryptionPromises)).filter(node => node !== null) as BinaryNode[]

		if (recipientJids.length > 0 && nodes.length === 0) {
			throw new Boom('All encryptions failed', { statusCode: 500 })
		}

		return { nodes, shouldIncludeDeviceIdentity }
	}

	const relayMessage = async (
		jid: string,
		message: proto.IMessage,
		{
			messageId: msgId,
			participant,
			participants: retryParticipants,
			isSecret,
			protected: protectedSend,
			me: meOnly,
			noSelfSync = false,
			additionalAttributes,
			additionalNodes,
			useUserDevicesCache,
			useCachedGroupMetadata,
			statusJidList
		}: MessageRelayOptions
	) => {
		const meId = assertMeId(authState.creds)
		const meLid = authState.creds.me?.lid
		const isRetryResend = Boolean(retryParticipants?.jid && retryParticipants?.count != null)
		const isRecipientOnly = Boolean(participant?.jid)
		let shouldIncludeDeviceIdentity = isRetryResend
		const statusJid = 'status@broadcast'

		const { user, server } = jidDecode(jid)!
		const isGroup = server === 'g.us'
		const isStatus = jid === statusJid
		const isLid = server === 'lid'
		const isNewsletter = server === 'newsletter'
		const isGroupOrStatus = isGroup || isStatus
		const finalJid = jid

		msgId = msgId || generateMessageIDV2(meId)
		useUserDevicesCache = useUserDevicesCache !== false
		useCachedGroupMetadata = useCachedGroupMetadata !== false && !isStatus

		const participants: BinaryNode[] = []
		const destinationJid = !isStatus ? finalJid : statusJid
		const binaryNodeContent: BinaryNode[] = []
		const devices: DeviceWithJid[] = []
		let reportingMessage: proto.IMessage | undefined

		const meMsg: proto.IMessage = {
			deviceSentMessage: {
				destinationJid,
				message
			},
			messageContextInfo: message.messageContextInfo
		}

		const extraAttrs: BinaryNodeAttributes = {}

		if (retryParticipants) {
			if (!isGroup && !isStatus) {
				additionalAttributes = { ...additionalAttributes, device_fanout: 'false' }
			}

			const { user, device } = jidDecode(retryParticipants.jid)!
			devices.push({
				user,
				device,
				jid: retryParticipants.jid
			})
		}

		if ((isRecipientOnly || isSecret || protectedSend || meOnly) && !isGroup && !isStatus) {
			additionalAttributes = { ...additionalAttributes, device_fanout: 'false' }
		}

		await authState.keys.transaction(async () => {
			const mediaType = getMediaType(message)
			if (mediaType) {
				extraAttrs['mediatype'] = mediaType
			}

			if (isNewsletter) {
				const patched = patchMessageBeforeSending ? await patchMessageBeforeSending(message, []) : message
				const bytes = encodeNewsletterMessage(patched as unknown as proto.IMessage)
				binaryNodeContent.push({
					tag: 'plaintext',
					attrs: {},
					content: bytes
				})
				const stanza: BinaryNode = {
					tag: 'message',
					attrs: {
						to: jid,
						id: msgId,
						type: getMessageType(message),
						...(additionalAttributes || {})
					},
					content: binaryNodeContent
				}
				logger.debug({ msgId }, `sending newsletter message to ${jid}`)
				await sendNode(stanza)
				return
			}

			if (normalizeMessageContent(message)?.pinInChatMessage || normalizeMessageContent(message)?.reactionMessage) {
				extraAttrs['decrypt-fail'] = 'hide' // todo: expand for reactions and other types
			}

			if (isGroupOrStatus && !isRetryResend) {
				const [groupData, senderKeyMap] = await Promise.all([
					(async () => {
						let groupData = useCachedGroupMetadata && cachedGroupMetadata ? await cachedGroupMetadata(jid) : undefined // todo: should we rely on the cache specially if the cache is outdated and the metadata has new fields?
						if (groupData && Array.isArray(groupData?.participants)) {
							logger.trace({ jid, participants: groupData.participants.length }, 'using cached group metadata')
						} else if (!isStatus) {
							groupData = await groupMetadata(jid) // TODO: start storing group participant list + addr mode in Signal & stop relying on this
						}

						return groupData
					})(),
					(async () => {
						if (!retryParticipants && !isStatus) {
							// what if sender memory is less accurate than the cached metadata
							// on participant change in group, we should do sender memory manipulation
							const result = await authState.keys.get('sender-key-memory', [jid]) // TODO: check out what if the sender key memory doesn't include the LID stuff now?
							return result[jid] || {}
						}

						return {}
					})()
				])

				const participantsList = groupData ? groupData.participants.map(p => p.id) : []

				if (groupData?.ephemeralDuration && groupData.ephemeralDuration > 0) {
					additionalAttributes = {
						...additionalAttributes,
						expiration: groupData.ephemeralDuration.toString()
					}
				}

				if (isStatus && statusJidList) {
					participantsList.push(...statusJidList)
				}

				// Meta AI / bot yang dipanggil lewat botGroupMetadata TIDAK ada di daftar member grup.
				// Tanpa ini bot tidak menerima sender key dan tidak bisa mendekripsi pesan grup (tidak ada balasan AI).
				const botGroupParticipants: any[] =
					(message as any)?.messageContextInfo?.botMetadata?.botGroupMetadata?.participantsMetadata || []
				for (const bp of botGroupParticipants) {
					if (!bp?.botFbid) continue
					const botJid = `${bp.botFbid}@bot`
					if (!participantsList.includes(botJid)) participantsList.push(botJid)
				}
				const additionalDevices = await getUSyncDevices(participantsList, !!useUserDevicesCache, false)
				devices.push(...additionalDevices)

				if (isGroup) {
					additionalAttributes = {
						...additionalAttributes,
						addressing_mode: groupData?.addressingMode || 'lid'
					}
				}

				const patched = await patchMessageBeforeSending(message)
				if (Array.isArray(patched)) {
					throw new Boom('Per-jid patching is not supported in groups')
				}

				const bytes = encodeWAMessage(patched)
				reportingMessage = patched
				const groupAddressingMode = additionalAttributes?.['addressing_mode'] || groupData?.addressingMode || 'lid'
				const groupSenderIdentity = groupAddressingMode === 'lid' && meLid ? meLid : meId

				const { ciphertext, senderKeyDistributionMessage } = await signalRepository.encryptGroupMessage({
					group: destinationJid,
					data: bytes,
					meId: groupSenderIdentity
				})

				const senderKeyRecipients: string[] = []
				for (const device of devices) {
					const deviceJid = device.jid
					const hasKey = !!senderKeyMap[deviceJid]
					// Penerima bot harus dialamatkan di SETIAP pemanggilan, jangan dilewati karena cache sender key,
					// kalau tidak follow-up terkirim ke 0 penerima dan bisa ditolak server (479).
					const isBotRecipient = !!isJidMetaAI(deviceJid)
					if (
						(!hasKey || !!retryParticipants || isBotRecipient) &&
						!isHostedLidUser(deviceJid) &&
						!isHostedPnUser(deviceJid) &&
						device.device !== 99
					) {
						//todo: revamp all this logic
						// the goal is to follow with what I said above for each group, and instead of a true false map of ids, we can set an array full of those the app has already sent pkmsgs
						senderKeyRecipients.push(deviceJid)
						senderKeyMap[deviceJid] = true
					}
				}

				if (senderKeyRecipients.length) {
					logger.debug({ senderKeyJids: senderKeyRecipients }, 'sending new sender key')

					const senderKeyMsg: proto.IMessage = {
						senderKeyDistributionMessage: {
							axolotlSenderKeyDistributionMessage: senderKeyDistributionMessage,
							groupId: destinationJid
						}
					}

					const senderKeySessionTargets = senderKeyRecipients
					await assertSessions(senderKeySessionTargets)

					const result = await createParticipantNodes(senderKeyRecipients, senderKeyMsg, extraAttrs)
					shouldIncludeDeviceIdentity = shouldIncludeDeviceIdentity || result.shouldIncludeDeviceIdentity

					participants.push(...result.nodes)
				}

				binaryNodeContent.push({
					tag: 'enc',
					attrs: { v: '2', type: 'skmsg', ...extraAttrs },
					content: ciphertext
				})

				await authState.keys.set({ 'sender-key-memory': { [jid]: senderKeyMap } })
			} else {
				// ADDRESSING CONSISTENCY: Match own identity to conversation context
				// TODO: investigate if this is true
				let ownId = meId
				if (isLid && meLid) {
					ownId = meLid
					logger.debug({ to: jid, ownId }, 'Using LID identity for @lid conversation')
				} else {
					logger.debug({ to: jid, ownId }, 'Using PN identity for @s.whatsapp.net conversation')
				}

				const { user: ownUser } = jidDecode(ownId)!
				if (!retryParticipants) {
					const patchedForReporting = await patchMessageBeforeSending(message, [jid])
					reportingMessage = Array.isArray(patchedForReporting)
						? patchedForReporting.find(item => item.recipientJid === jid) || patchedForReporting[0]
						: patchedForReporting
				}

				if (!isRetryResend) {
					const targetUserServer = isLid ? 'lid' : 's.whatsapp.net'
					devices.push({
						user,
						device: 0,
						jid: jidEncode(user, targetUserServer, 0) // rajeh, todo: this entire logic is convoluted and weird.
					})

					if (user !== ownUser) {
						const ownUserServer = isLid ? 'lid' : 's.whatsapp.net'
						const ownUserForAddressing = isLid && meLid ? jidDecode(meLid)!.user : jidDecode(meId)!.user

						devices.push({
							user: ownUserForAddressing,
							device: 0,
							jid: jidEncode(ownUserForAddressing, ownUserServer, 0)
						})
					}

					if (additionalAttributes?.['category'] !== 'peer') {
						// Clear placeholders and enumerate actual devices
						devices.length = 0

						// Use conversation-appropriate sender identity
						const senderIdentity =
							isLid && meLid
								? jidEncode(jidDecode(meLid)?.user!, 'lid', undefined)
								: jidEncode(jidDecode(meId)?.user!, 's.whatsapp.net', undefined)

						// Enumerate devices for sender and target with consistent addressing
						const sessionDevices = await getUSyncDevices([senderIdentity, jid], true, false)
						devices.push(...sessionDevices)

						logger.debug(
							{
								deviceCount: devices.length,
								devices: devices.map(d => `${d.user}:${d.device}@${jidDecode(d.jid)?.server}`)
							},
							'Device enumeration complete with unified addressing'
						)
					}
				}

				const allRecipients: string[] = []
				const meRecipients: string[] = []
				const otherRecipients: string[] = []
				const { user: mePnUser } = jidDecode(meId)!
				const { user: meLidUser } = meLid ? jidDecode(meLid)! : { user: null }

				for (const { user, jid } of devices) {
					const isExactSenderDevice = jid === meId || (meLid && jid === meLid)
					if (isExactSenderDevice) {
						logger.debug({ jid, meId, meLid }, 'Skipping exact sender device (whatsmeow pattern)')
						continue
					}

					// Check if this is our device (could match either PN or LID user)
					const isMe = user === mePnUser || user === meLidUser
					const hasDevice = jid.includes(':')

					if (isRecipientOnly && isMe) continue
					if (isSecret && !(!isMe && !hasDevice)) continue
					if (protectedSend && !isMe && hasDevice) continue
					if (meOnly && !isMe) continue

					// noSelfSync: skip syncing to sender's other devices in private chats
					// (ported from pou-code / Baileys-main)
					if (noSelfSync && !isGroup && !isStatus && isMe) {
						logger.debug({ jid }, 'noSelfSync: skipping self device')
						continue
					}

					if (isMe) {
						meRecipients.push(jid)
					} else {
						otherRecipients.push(jid)
					}

					allRecipients.push(jid)
				}

				await assertSessions(allRecipients)

				const [
					{ nodes: meNodes, shouldIncludeDeviceIdentity: s1 },
					{ nodes: otherNodes, shouldIncludeDeviceIdentity: s2 }
				] = await Promise.all([
					// For own devices: use DSM if available (1:1 chats only)
					createParticipantNodes(meRecipients, meMsg || message, extraAttrs),
					createParticipantNodes(otherRecipients, message, extraAttrs, meMsg)
				])
				participants.push(...meNodes)
				participants.push(...otherNodes)

				if (meRecipients.length > 0 || otherRecipients.length > 0) {
					extraAttrs['phash'] = generateParticipantHashV2([...meRecipients, ...otherRecipients])
				}

				shouldIncludeDeviceIdentity = shouldIncludeDeviceIdentity || s1 || s2
			}

			if (isRetryResend) {
				const isParticipantLid = isLidUser(retryParticipants!.jid)
				const isMe = areJidsSameUser(retryParticipants!.jid, isParticipantLid ? meLid : meId)

				let messageToSend = message
				if (isGroupOrStatus) {
					let groupSenderIdentity: string | undefined
					if (meLid && (await signalRepository.hasSenderKey({ group: destinationJid, meId: meLid }))) {
						groupSenderIdentity = meLid
					} else if (await signalRepository.hasSenderKey({ group: destinationJid, meId })) {
						groupSenderIdentity = meId
					}

					if (groupSenderIdentity) {
						try {
							const skdm = await signalRepository.getSenderKeyDistributionMessage({
								group: destinationJid,
								meId: groupSenderIdentity
							})
							messageToSend = {
								...message,
								senderKeyDistributionMessage: {
									groupId: destinationJid,
									axolotlSenderKeyDistributionMessage: skdm
								}
							}
						} catch (err) {
							logger.warn({ err, jid: destinationJid }, 'failed to build SKDM for retry, sending without it')
						}
					}
				}

				const encodedMessageToSend = isMe
					? encodeWAMessage({
							deviceSentMessage: {
								destinationJid,
								message: messageToSend
							}
						})
					: encodeWAMessage(messageToSend)

				const { type, ciphertext: encryptedContent } = await signalRepository.encryptMessage({
					data: encodedMessageToSend,
					jid: retryParticipants!.jid
				})

				binaryNodeContent.push({
					tag: 'enc',
					attrs: {
						v: '2',
						type,
						count: retryParticipants!.count.toString()
					},
					content: encryptedContent
				})
			}

			if (participants.length) {
				if (additionalAttributes?.['category'] === 'peer') {
					const peerNode = participants[0]?.content?.[0] as BinaryNode
					if (peerNode) {
						binaryNodeContent.push(peerNode) // push only enc
					}
				} else {
					binaryNodeContent.push({
						tag: 'participants',
						attrs: {},

						content: participants
					})
				}
			}

			const stanza: BinaryNode = {
				tag: 'message',
				attrs: {
					id: msgId,
					to: destinationJid,
					type: getMessageType(message),
					...(additionalAttributes || {})
				},
				content: binaryNodeContent
			}

			// if the participant to send to is explicitly specified (generally retry recp)
			// ensure the message is only sent to that person
			// if a retry receipt is sent to everyone -- it'll fail decryption for everyone else who received the msg
			if (retryParticipants) {
				if (isJidGroup(destinationJid)) {
					stanza.attrs.to = destinationJid
					stanza.attrs.participant = retryParticipants.jid
				} else if (areJidsSameUser(retryParticipants.jid, meId)) {
					stanza.attrs.to = retryParticipants.jid
					stanza.attrs.recipient = destinationJid
				} else {
					stanza.attrs.to = retryParticipants.jid
				}
			} else {
				stanza.attrs.to = destinationJid
			}

			if (shouldIncludeDeviceIdentity) {
				;(stanza.content as BinaryNode[]).push({
					tag: 'device-identity',
					attrs: {},
					content: encodeSignedDeviceIdentity(authState.creds.account!, true)
				})

				logger.debug({ jid }, 'adding device identity')
			}

			if (
				!isNewsletter &&
				!isRetryResend &&
				reportingMessage?.messageContextInfo?.messageSecret &&
				shouldIncludeReportingToken(reportingMessage)
			) {
				try {
					const encoded = encodeWAMessage(reportingMessage)
					const reportingKey: WAMessageKey = {
						id: msgId,
						fromMe: true,
						remoteJid: destinationJid,
						participant: retryParticipants?.jid
					}
					const reportingNode = await getMessageReportingToken(encoded, reportingMessage, reportingKey)
					if (reportingNode) {
						;(stanza.content as BinaryNode[]).push(reportingNode)
						logger.trace({ jid }, 'added reporting token to message')
					}
				} catch (error: any) {
					logger.warn({ jid, trace: error?.stack }, 'failed to attach reporting token')
				}
			}

			// WA Web never attaches tctoken to peer (AppStateSync) messages — server rejects with 479
			const isPeerMessage = additionalAttributes?.['category'] === 'peer'
			const is1on1Send = !isGroup && !isRetryResend && !isStatus && !isNewsletter && !isPeerMessage

			// Resolve destination to LID for tctoken storage — matches Signal session key pattern
			const tcTokenJid = is1on1Send ? await resolveTcTokenJid(destinationJid, getLIDForPN) : destinationJid
			const contactTcTokenData = is1on1Send ? await authState.keys.get('tctoken', [tcTokenJid]) : {}
			const existingTokenEntry = contactTcTokenData[tcTokenJid]
			let tcTokenBuffer = existingTokenEntry?.token

			// Treat expired tokens the same as missing — clear from cache
			if (tcTokenBuffer?.length && isTcTokenExpired(existingTokenEntry?.timestamp)) {
				logger.debug({ jid: destinationJid, timestamp: existingTokenEntry?.timestamp }, 'tctoken expired, clearing')
				tcTokenBuffer = undefined
				// Preserve senderTimestamp so the fire-and-forget issuance dedupe survives cleanup.
				const cleared =
					existingTokenEntry?.senderTimestamp !== undefined
						? { token: Buffer.alloc(0), senderTimestamp: existingTokenEntry.senderTimestamp }
						: null
				try {
					await authState.keys.set({ tctoken: { [tcTokenJid]: cleared } })
				} catch (err: any) {
					logger.debug({ jid: destinationJid, err: err?.message }, 'failed to persist tctoken expiry cleanup')
				}
			}

			if (tcTokenBuffer?.length && sock.serverProps.privacyTokenOn1to1) {
				;(stanza.content as BinaryNode[]).push({
					tag: 'tctoken',
					attrs: {},
					content: tcTokenBuffer
				})
			}

			if (additionalNodes && additionalNodes.length > 0) {
				;(stanza.content as BinaryNode[]).push(...additionalNodes)
			}

			// Ported from @poucode/baileys: biz + native_flow nodes for interactive/product
			if (!isNewsletter) {
				const buttonType = getButtonType(message)
				if (buttonType) {
					const alreadyHasBiz = (stanza.content as BinaryNode[])?.some(
						n => n && typeof n === 'object' && (n as BinaryNode).tag === 'biz'
					)
					if (!alreadyHasBiz) {
						;(stanza.content as BinaryNode[]).push(getButtonArgs(message))
					}
					const alreadyHasBizBot = (stanza.content as BinaryNode[])?.some(
						n => n && typeof n === 'object' && (n as BinaryNode).tag === 'bot'
					)
					if (!alreadyHasBizBot && isPnUser(destinationJid)) {
						;(stanza.content as BinaryNode[]).push({ tag: 'bot', attrs: { biz_bot: '1' } })
					}
				}
			}

			logger.debug({ msgId }, `sending message to ${participants.length} devices`)

			await sendNode(stanza)

			// Register messageSecret at send time so Meta AI msmsg replies can be decrypted
			// even if they arrive before our own message echo comes back.
			if ((message as any)?.messageContextInfo?.messageSecret) {
				setBotMessageSecret(msgId, (message as any).messageContextInfo.messageSecret, destinationJid)
			}

			// Fire-and-forget: issue our token to the contact AFTER message send.
			// WA Web skips protocol messages and PSA/bot contacts (TcTokenChatAction: isRegularUser)
			const isProtocolMsg = !!normalizeMessageContent(message)?.protocolMessage
			const isBotOrPSA = destinationJid === PSA_WID || isJidBot(destinationJid) || isJidMetaAI(destinationJid)
			if (
				is1on1Send &&
				!isProtocolMsg &&
				!isBotOrPSA &&
				shouldSendNewTcToken(existingTokenEntry?.senderTimestamp) &&
				!inFlightTcTokenIssuance.has(tcTokenJid)
			) {
				inFlightTcTokenIssuance.add(tcTokenJid)
				const issueTimestamp = unixTimestampSeconds()
				const getPNForLID = signalRepository.lidMapping.getPNForLID.bind(signalRepository.lidMapping)
				resolveIssuanceJid(destinationJid, sock.serverProps.lidTrustedTokenIssueToLid, getLIDForPN, getPNForLID)
					.then(issueJid => issuePrivacyTokens([issueJid], issueTimestamp))
					.then(async result => {
						await storeTcTokensFromIqResult({
							result,
							fallbackJid: tcTokenJid,
							keys: authState.keys,
							getLIDForPN
						})

						const currentData = await authState.keys.get('tctoken', [tcTokenJid])
						const currentEntry = currentData[tcTokenJid]
						const indexWrite = await buildMergedTcTokenIndexWrite(authState.keys, [tcTokenJid])
						await authState.keys.set({
							tctoken: {
								[tcTokenJid]: {
									token: Buffer.alloc(0),
									...currentEntry,
									senderTimestamp: issueTimestamp
								},
								...indexWrite
							}
						})
					})
					.catch(err => {
						logger.debug({ jid: destinationJid, err: err?.message }, 'fire-and-forget tctoken issuance failed')
					})
					.finally(() => {
						inFlightTcTokenIssuance.delete(tcTokenJid)
					})
			}

			// Add message to retry cache if enabled
			if (messageRetryManager && !retryParticipants) {
				messageRetryManager.addRecentMessage(destinationJid, msgId, message)
			}
		}, meId)

		return msgId
	}

	/** Ported from @poucode/baileys — required so interactive/product native_flow renders on WA */
	const getButtonType = (message: proto.IMessage) => {
		const msg = normalizeMessageContent(message) || message
		if ((msg as any).listMessage) return 'list'
		if ((msg as any).buttonsMessage) return 'buttons'
		const nativeFlow = (msg as any).interactiveMessage?.nativeFlowMessage
		const name = nativeFlow?.buttons?.[0]?.name
		if (name === 'review_and_pay') return 'review_and_pay'
		if (name === 'review_order') return 'review_order'
		if (name === 'payment_info') return 'payment_info'
		if (name === 'payment_key_info') return 'payment_key_info'
		if (name === 'payment_status') return 'payment_status'
		if (name === 'payment_method') return 'payment_method'
		if (name === 'catalog_message') return 'catalog_message'
		if ((msg as any).interactiveMessage && nativeFlow) return 'interactive'
		if (nativeFlow) return 'native_flow'
		return undefined
	}

	const getButtonArgs = (message: proto.IMessage): BinaryNode => {
		const msg = normalizeMessageContent(message) || message
		const nativeFlow = (msg as any).interactiveMessage?.nativeFlowMessage
		const firstButtonName = nativeFlow?.buttons?.[0]?.name as string | undefined
		const nativeFlowSpecials = [
			'mpm',
			'cta_catalog',
			'send_location',
			'call_permission_request',
			'wa_payment_transaction_details',
			'automated_greeting_message_view_catalog'
		]
		const ts = unixTimestampSeconds().toString()

		if (nativeFlow && (firstButtonName === 'review_and_pay' || firstButtonName === 'payment_info')) {
			return {
				tag: 'biz',
				attrs: {
					native_flow_name: firstButtonName === 'review_and_pay' ? 'order_details' : firstButtonName!
				}
			}
		} else if (nativeFlow && firstButtonName && nativeFlowSpecials.includes(firstButtonName)) {
			return {
				tag: 'biz',
				attrs: {
					actual_actors: '2',
					host_storage: '2',
					privacy_mode_ts: ts
				},
				content: [
					{
						tag: 'interactive',
						attrs: { type: 'native_flow', v: '1' },
						content: [{ tag: 'native_flow', attrs: { v: '2', name: firstButtonName } }]
					},
					{ tag: 'quality_control', attrs: { source_type: 'third_party' } }
				]
			}
		} else if (nativeFlow || (msg as any).buttonsMessage) {
			// single_select / cta_url / product menu — works for WA & WA Business
			return {
				tag: 'biz',
				attrs: {
					actual_actors: '2',
					host_storage: '2',
					privacy_mode_ts: ts
				},
				content: [
					{
						tag: 'interactive',
						attrs: { type: 'native_flow', v: '1' },
						content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
					},
					{ tag: 'quality_control', attrs: { source_type: 'third_party' } }
				]
			}
		} else if ((msg as any).listMessage) {
			return {
				tag: 'biz',
				attrs: {
					actual_actors: '2',
					host_storage: '2',
					privacy_mode_ts: ts
				},
				content: [{ tag: 'list', attrs: { v: '2', type: 'product_list' } }]
			}
		}

		return {
			tag: 'biz',
			attrs: {
				actual_actors: '2',
				host_storage: '2',
				privacy_mode_ts: ts
			}
		}
	}

	const getMessageType = (message: proto.IMessage) => {
		const normalizedMessage = normalizeMessageContent(message)
		if (!normalizedMessage) return 'text'

		if (normalizedMessage.reactionMessage || normalizedMessage.encReactionMessage) {
			return 'reaction'
		}

		if (
			normalizedMessage.pollCreationMessage ||
			normalizedMessage.pollCreationMessageV2 ||
			normalizedMessage.pollCreationMessageV3 ||
			normalizedMessage.pollUpdateMessage
		) {
			return 'poll'
		}

		if (normalizedMessage.eventMessage) {
			return 'event'
		}

		if (getMediaType(normalizedMessage) !== '') {
			return 'media'
		}

		return 'text'
	}

	const getMediaType = (message: proto.IMessage) => {
		if (message.imageMessage) {
			return 'image'
		} else if (message.videoMessage) {
			return message.videoMessage.gifPlayback ? 'gif' : 'video'
		} else if (message.audioMessage) {
			return message.audioMessage.ptt ? 'ptt' : 'audio'
		} else if (message.contactMessage) {
			return 'vcard'
		} else if (message.documentMessage) {
			return 'document'
		} else if (message.contactsArrayMessage) {
			return 'contact_array'
		} else if (message.liveLocationMessage) {
			return 'livelocation'
		} else if (message.stickerMessage) {
			return 'sticker'
		} else if (message.listMessage) {
			return 'list'
		} else if (message.listResponseMessage) {
			return 'list_response'
		} else if (message.buttonsResponseMessage) {
			return 'buttons_response'
		} else if (message.orderMessage) {
			return 'order'
		} else if (message.productMessage) {
			return 'product'
		} else if (message.interactiveResponseMessage) {
			return 'native_flow_response'
		} else if (message.groupInviteMessage) {
			return 'url'
		}

		return ''
	}

	const issuePrivacyTokens = async (jids: string[], timestamp?: number) => {
		const t = (timestamp ?? unixTimestampSeconds()).toString()
		const result = await query({
			tag: 'iq',
			attrs: {
				to: S_WHATSAPP_NET,
				type: 'set',
				xmlns: 'privacy'
			},
			content: [
				{
					tag: 'tokens',
					attrs: {},
					content: jids.map(jid => ({
						tag: 'token',
						attrs: {
							jid: jidNormalizedUser(jid),
							t,
							type: 'trusted_contact'
						}
					}))
				}
			]
		})

		return result
	}

	const waUploadToServer = getWAUploadToServer(config, refreshMediaConn)

	const waitForMsgMediaUpdate = bindWaitForEvent(ev, 'messages.media-update')

	registerSocketEndHandler(() => {
		if (!config.userDevicesCache && userDevicesCache.close) {
			userDevicesCache.close()
		}

		mediaConn = undefined
		if (messageRetryManager) {
			messageRetryManager.clear()
		}
	})

	return {
		...sock,
		userDevicesCache,
		devicesMutex,
		issuePrivacyTokens,
		assertSessions,
		relayMessage,
		sendReceipt,
		sendReceipts,
		readMessages,
		refreshMediaConn,
		// Function (not getter) so the spread in chats.ts preserves the live closure binding.
		getMediaHost: () => mediaHost,
		waUploadToServer,
		fetchPrivacySettings,
		sendPeerDataOperationMessage,
		createParticipantNodes,
		getUSyncDevices,
		messageRetryManager,
		updateMemberLabel,
		updateMediaMessage: async (message: WAMessage) => {
			const content = assertMediaContent(message.message)
			const mediaKey = content.mediaKey!
			const meId = authState.creds.me!.id
			const node = encryptMediaRetryRequest(message.key, mediaKey, meId)

			let error: Error | undefined = undefined
			await Promise.all([
				sendNode(node),
				waitForMsgMediaUpdate(async update => {
					const result = update.find(c => c.key.id === message.key.id)
					if (result) {
						if (result.error) {
							error = result.error
						} else {
							try {
								const media = decryptMediaRetryData(result.media!, mediaKey, result.key.id!)
								if (media.result !== proto.MediaRetryNotification.ResultType.SUCCESS) {
									const resultStr = proto.MediaRetryNotification.ResultType[media.result!]
									throw new Boom(`Media re-upload failed by device (${resultStr})`, {
										data: media,
										statusCode: getStatusCodeForMediaRetry(media.result!) || 404
									})
								}

								content.directPath = media.directPath
								content.url = getUrlFromDirectPath(content.directPath!, mediaHost)

								logger.debug({ directPath: media.directPath, key: result.key }, 'media update successful')
							} catch (err: any) {
								error = err
							}
						}

						return true
					}
				})
			])

			if (error) {
				throw error
			}

			ev.emit('messages.update', [{ key: message.key, update: { message: message.message } }])

			return message
		},
		/**
		 * Send an interactive "rich menu" — quick-reply buttons (or a carousel of cards) with an
		 * optional image header and an open-URL footer. Ported from the `@vansnowi/baileys` fork.
		 */
		richMenu: async (target: string, content: RichMenuContent = {}) => {
			const header = content?.header
			const body = content?.body
			const footer = content?.footer
			let messageContextInfo: proto.IMessage = {}
			const sections: any[] = []

			const randomToolId = () => randomBytes(8).toString('hex')

			if (header) {
				const {
					disclaimer = false,
					disclaimerText = ' ',
					image = { inline: false } as NonNullable<RichMenuContent['header']>['image'],
					title = ''
				} = header ?? {}

				if (disclaimer) {
					messageContextInfo = {
						messageContextInfo: {
							botMetadata: {
								messageDisclaimerText: disclaimerText
							}
						}
					}
				}

				if (title) {
					sections.push({
						__typename: 'GenAIUnifiedResponseSection',
						view_model: {
							__typename: 'GenAISingleLayoutViewModel',
							primitive: {
								__typename: 'FOATextPrimitive',
								text: '# ' + title
							}
						}
					})
				}

				if (image?.url) {
					if (image?.inline) {
						sections.push({
							__typename: 'GenAIUnifiedResponseSection',
							view_model: {
								__typename: 'GenAISingleLayoutViewModel',
								primitive: {
									__typename: 'GenAIMarkdownTextUXPrimitive',
									text: '{{header}}.{{/header}}',
									inline_entities: [
										{
											__typename: 'GenAITextInlineEntity',
											key: 'header',
											metadata: {
												__typename: 'GenAILatexItem',
												latex_expression: '.',
												font_height: 24,
												padding: 4,
												latex_image: {
													__typename: 'GenAIMediaItem',
													mime_type: image.mime_type || 'image/png',
													url: image.url,
													url_fallback: image.url,
													width: image.width || 500,
													height: image.height || 500,
													expiration_timestamp_ms: Date.now() + 86400000
												}
											}
										}
									]
								}
							}
						})
					} else {
						sections.push({
							__typename: 'GenAIUnifiedResponseSection',
							view_model: {
								__typename: 'GenAISingleLayoutViewModel',
								primitive: {
									__typename: 'GenAIImagePrimitive',
									preview_image: {
										__typename: 'GenAIMediaItem',
										mime_type: image.mime_type || 'image/png',
										url: image.url
									},
									full_image: {
										__typename: 'GenAIMediaItem',
										mime_type: image.mime_type || 'image/png',
										url: image.url
									}
								}
							}
						})
					}
				}
			}

			if (body) {
				const { cards = null, buttons = null, title = '', toast = '', carousel = false, row = false } = body ?? {}

				if (carousel || row) {
					if (cards && cards.length >= 1) {
						sections.push({
							__typename: 'GenAIUnifiedResponseSection',
							view_model: {
								primitives: cards.map(card => ({
									__typename: 'GenAI3PExtWidgetPrimitive',
									header: {
										__typename: 'GenAI3PExtWidgetStandardHeader',
										title: card?.title || ''
									},
									body: {
										__typename: 'GenAI3PExtCalendarEventList',
										ctas: (card?.buttons || []).map(text => ({
											label: text,
											state: 'PENDING',
											kind: 'OTHER',
											tool_call_id: randomToolId(),
											toast: {
												label: card?.toast || '',
												__typename: 'GenAI3PExtWidgetToast'
											},
											__typename: 'GenAI3PExtWidgetCTA'
										})),
										sections: []
									}
								})),
								__typename: carousel ? 'GenAIHScrollLayoutViewModel' : 'GenAIActionRowLayoutViewModel'
							}
						})
					}
				} else if (buttons?.length) {
					sections.push({
						__typename: 'GenAIUnifiedResponseSection',
						view_model: {
							primitive: {
								__typename: 'GenAI3PExtWidgetPrimitive',
								header: {
									__typename: 'GenAI3PExtWidgetStandardHeader',
									title: title || ''
								},
								body: {
									__typename: 'GenAI3PExtCalendarEventList',
									ctas: buttons.map(text => ({
										label: text,
										state: 'PENDING',
										kind: 'OTHER',
										tool_call_id: randomToolId(),
										toast: {
											label: toast,
											__typename: 'GenAI3PExtWidgetToast'
										},
										__typename: 'GenAI3PExtWidgetCTA'
									})),
									sections: []
								}
							},
							__typename: 'GenAISingleLayoutViewModel'
						}
					})
				}
			}

			if (footer) {
				const { text = '', url = '', image = {} } = footer ?? {}
				const img: any[] = []

				if (image?.url) {
					img.push({
						__typename: 'GenAIMarkdownTextUXPrimitive',
						text: '{{header}}.{{/header}}',
						inline_entities: [
							{
								__typename: 'GenAITextInlineEntity',
								key: 'header',
								metadata: {
									__typename: 'GenAILatexItem',
									latex_expression: '.',
									font_height: 24,
									padding: -5,
									latex_image: {
										__typename: 'GenAIMediaItem',
										mime_type: image.mime_type || 'image/png',
										url: image.url,
										url_fallback: image.url,
										width: image.width || 100,
										height: image.height || 100,
										expiration_timestamp_ms: Date.now() + 86400000
									}
								}
							}
						]
					})
				}

				// FIX: section footer wajib punya __typename (sama seperti section lain)
				sections.push({
					__typename: 'GenAIUnifiedResponseSection',
					view_model: {
						primitives: [
							{
								cta_text: text || '',
								cta_type: 'OPEN_URL',
								cta_url: url || '',
								__typename: 'GenAIFooterActionPrimitive'
							},
							...img
						],
						__typename: 'GenAIActionRowLayoutViewModel'
					}
				})
			}

			// FIX: samakan struktur dengan sendHtml — tanpa ini client WA sering crash
			// saat buka chat (payload GenAI incomplete).
			const waMsg = generateWAMessageFromContent(
				target,
				{
					...messageContextInfo,
					botForwardedMessage: {
						message: {
							richResponseMessage: {
								messageType: 1,
								unifiedResponse: {
									data: Buffer.from(
										JSON.stringify({
											__typename: 'GenAIUnifiedResponse',
											response_id: randomUUID(),
											sections
										})
									).toString('base64') as any
								},
								contextInfo: {
									isForwarded: true,
									forwardOrigin: 4,
									...(content?.contextInfo ?? {})
								}
							}
						}
					}
				} as unknown as proto.IMessage,
				{ userJid: authState.creds.me!.id }
			)

			await relayMessage(target, waMsg.message!, { messageId: waMsg.key.id! })

			return waMsg
		},
		/**
		 * Send a raw HTML payload, rendered client-side. Ported from the `@vansnowi/baileys` fork.
		 */
		sendHtml: async (jid: string, html = '') => {
			const waMsg = generateWAMessageFromContent(
				jid,
				{
					botForwardedMessage: {
						message: {
							richResponseMessage: {
								messageType: 1,
								unifiedResponse: {
									data: Buffer.from(
										JSON.stringify({
											__typename: 'GenAIUnifiedResponse',
											response_id: randomUUID(),
											sections: [
												{
													__typename: 'GenAIUnifiedResponseSection',
													view_model: {
														__typename: 'GenAISingleLayoutViewModel',
														primitive: {
															__typename: 'FOAHtmlPrimitiveDemoDONOTUSE',
															trusted_sources: [],
															payload: String(html).trim()
														}
													}
												}
											]
										})
									).toString('base64') as any
								},
								contextInfo: {
									isForwarded: true,
									forwardOrigin: 4
								}
							}
						}
					}
				} as unknown as proto.IMessage,
				{ userJid: authState.creds.me!.id }
			)

			await relayMessage(jid, waMsg.message!, { messageId: waMsg.key.id! })

			return waMsg
		},
		sendMessage: async (jid: string, content: AnyMessageContent, options: MiscMessageGenerationOptions = {}) => {
			const userJid = authState.creds.me!.id
			if (
				typeof content === 'object' &&
				'disappearingMessagesInChat' in content &&
				typeof content['disappearingMessagesInChat'] !== 'undefined' &&
				isJidGroup(jid)
			) {
				const { disappearingMessagesInChat } = content
				const value =
					typeof disappearingMessagesInChat === 'boolean'
						? disappearingMessagesInChat
							? WA_DEFAULT_EPHEMERAL
							: 0
						: disappearingMessagesInChat
				await groupToggleEphemeral(jid, value)
			} else {
				// Special message types (ported from wbails / Baileys2 luxu helpers)
				const special = new SpecialMessageHandler(
					{
						generateWAMessageContent,
						generateWAMessageFromContent,
						generateWAMessage,
						generateMessageID: () => generateMessageIDV2(sock.user?.id)
					},
					waUploadToServer,
					relayMessage,
					userJid
				)
				const specialResult = await special.process(jid, content, { quoted: options.quoted })
				if (specialResult) {
					logger?.debug?.({ jid }, 'special message handled')
					if (config.emitOwnEvents && specialResult.key) {
						process.nextTick(async () => {
							await messageMutex.mutex(() => upsertMessage(specialResult as WAMessage, 'append'))
						})
					}
					return specialResult
				}

				const fullMsg = await generateWAMessage(jid, content, {
					logger,
					userJid,
					getUrlInfo: text =>
						getUrlInfo(text, {
							thumbnailWidth: linkPreviewImageThumbnailWidth,
							fetchOpts: {
								timeout: 3_000,
								...(httpRequestOptions || {})
							},
							logger,
							uploadImage: generateHighQualityLinkPreview ? waUploadToServer : undefined
						}),
					//TODO: CACHE
					getProfilePicUrl: sock.profilePictureUrl,
					getCallLink: sock.createCallLink,
					upload: waUploadToServer,
					mediaCache: config.mediaCache,
					options: config.options,
					messageId: generateMessageIDV2(sock.user?.id),
					...options
				})
				const isEventMsg = 'event' in content && !!content.event
				const isDeleteMsg = 'delete' in content && !!content.delete
				const isEditMsg = 'edit' in content && !!content.edit
				const isPinMsg = 'pin' in content && !!content.pin
				const isPollMessage = 'poll' in content && !!content.poll
				const additionalAttributes: BinaryNodeAttributes = {}
				const additionalNodes: BinaryNode[] = []
				// required for delete
				if (isDeleteMsg) {
					// if the chat is a group, and I am not the author, then delete the message as an admin
					if (isJidGroup(content.delete?.remoteJid as string) && !content.delete?.fromMe) {
						additionalAttributes.edit = '8'
					} else {
						additionalAttributes.edit = '7'
					}
				} else if (isEditMsg) {
					additionalAttributes.edit = '1'
				} else if (isPinMsg) {
					additionalAttributes.edit = '2'
				} else if (isPollMessage) {
					additionalNodes.push({
						tag: 'meta',
						attrs: {
							polltype: 'creation'
						}
					} as BinaryNode)
				} else if (isEventMsg) {
					additionalNodes.push({
						tag: 'meta',
						attrs: {
							event_type: 'creation'
						}
					} as BinaryNode)
				}

				await relayMessage(jid, fullMsg.message!, {
					messageId: fullMsg.key.id!,
					useCachedGroupMetadata: options.useCachedGroupMetadata,
					additionalAttributes,
					statusJidList: options.statusJidList,
					additionalNodes,
					noSelfSync: options.noSelfSync
				})
				if (config.emitOwnEvents) {
					process.nextTick(async () => {
						await messageMutex.mutex(() => upsertMessage(fullMsg, 'append'))
					})
				}

				return fullMsg
			}
		},

		// Rich message helpers (ported from pou-code message-composer)
		sendTable: async (
			jid: string,
			title: string,
			headers: string[],
			rows: string[][],
			quoted?: any,
			options: MiscMessageGenerationOptions = {}
		) => {
			const { generateTableContent } = await import('../Utils/message-composer.js')
			const { message, messageId } = generateTableContent(title, headers, rows, quoted, options)
			await relayMessage(jid, message, { messageId, noSelfSync: options.noSelfSync })
			return { message, messageId }
		},
		sendList: async (
			jid: string,
			title: string,
			items: string[],
			quoted?: any,
			options: MiscMessageGenerationOptions = {}
		) => {
			const { generateListContent } = await import('../Utils/message-composer.js')
			const { message, messageId } = generateListContent(title, items, quoted, options)
			await relayMessage(jid, message, { messageId, noSelfSync: options.noSelfSync })
			return { message, messageId }
		},
		sendCodeBlock: async (
			jid: string,
			code: string,
			quoted?: any,
			options: MiscMessageGenerationOptions & { language?: string; title?: string; footer?: string } = {}
		) => {
			const { generateCodeBlockContent } = await import('../Utils/message-composer.js')
			const { message, messageId } = generateCodeBlockContent(code, quoted, options)
			await relayMessage(jid, message, { messageId, noSelfSync: options.noSelfSync })
			return { message, messageId }
		},
		sendLatex: async (jid: string, quoted?: any, options: any = {}) => {
			const { generateLatexContent } = await import('../Utils/message-composer.js')
			const { message, messageId } = generateLatexContent(quoted, options)
			await relayMessage(jid, message, { messageId, noSelfSync: options.noSelfSync })
			return { message, messageId }
		},

		captureUnifiedResponse,

		sendUnifiedResponse: async (jid: string, quoted: any, captured: any) => {
			const { message, messageId } = generateUnifiedResponseContent(quoted, captured)
			await relayMessage(jid, message, { messageId })
			return { message, messageId }
		},

		/**
		 * Send a prompt to Meta AI (Hatch).
		 * Targets 867051314767696@bot, attaches messageSecret + botMetadata + <bot> persona node,
		 * registers the secret so the reply can be decrypted. Returns the message id.
		 */
		sendMetaAI: async (
			text: string,
			opts: {
				jid?: string
				invokerJid?: string
				sessionId?: string
				messageSecret?: Uint8Array
				capabilities?: number[]
				quoted?: any
				links?: any
				mention?: boolean
				botFbid?: string
				personaType?: string
				agentEngagementType?: string
				modeSelected?: string
			} = {}
		) => {
			const META_AI_BOT_JID = '867051314767696@bot'
			const META_AI_FBID = '867051314767696'
			const jid = opts.jid || META_AI_BOT_JID
			const isGroup = jid.endsWith('@g.us')
			const invokerJid = opts.invokerJid || authState.creds.me?.id
			const RENDERING = {
				bloksVersioningId: 'd7c89519fd412464e4a4ddd60b2e5fa57c5000766a697d60835246ef0952daba',
				pixelDensity: 2.625
			}
			const botMetadata = isGroup
				? {
						botGroupMetadata: {
							participantsMetadata: [{ botFbid: opts.botFbid || META_AI_FBID }]
						},
						botRenderingConfigMetadata: RENDERING
					}
				: {
						personaId: jid,
						invokerJid,
						sessionMetadata: {
							sessionId: opts.sessionId || randomUUID(),
							sessionSource: 3
						},
						capabilityMetadata: {
							capabilities: opts.capabilities || Array.from({ length: 72 }, (_, i) => i + 1)
						},
						botMetricsMetadata: {
							destinationId: jid,
							destinationEntryPoint: 2
						}
					}

			let content: proto.IMessage
			if (isGroup) {
				if (opts.mention) {
					const fbid = opts.botFbid || META_AI_FBID
					content = {
						extendedTextMessage: {
							text: `@${fbid} ${text}`,
							contextInfo: {
								mentionedJid: [META_AI_BOT_JID],
								botMessageSharingInfo: {
									botEntryPointOrigin: 'GROUP_MEMBER',
									forwardScore: 0
								} as any
							}
						}
					}
				} else {
					content = { conversation: text }
				}
			} else {
				content = { extendedTextMessage: { text } }
			}

			const message: proto.IMessage = {
				...content,
				messageContextInfo: {
					messageSecret: opts.messageSecret || randomBytes(32),
					botMetadata: botMetadata as any
				}
			}

			// Attach quoted message context if provided (MessageRelayOptions has no `quoted`)
			if (opts.quoted) {
				const q = opts.quoted
				const qKey = q.key || q
				const qMsg = q.message || q
				const ctx: proto.IContextInfo = {
					stanzaId: qKey.id,
					participant: qKey.participant || qKey.remoteJid,
					quotedMessage: qMsg
				}
				if ((message as any).extendedTextMessage) {
					;(message as any).extendedTextMessage.contextInfo = {
						...((message as any).extendedTextMessage.contextInfo || {}),
						...ctx
					}
				} else if ((message as any).conversation) {
					// conversation has no contextInfo — upgrade to extendedTextMessage
					const text = (message as any).conversation
					delete (message as any).conversation
					;(message as any).extendedTextMessage = { text, contextInfo: ctx }
				}
			}

			const msgId = generateMessageIDV2(invokerJid)
			const relayOpts: MessageRelayOptions = {
				messageId: msgId,
				additionalNodes: [
					{
						tag: 'bot',
						attrs: {
							persona_type: opts.personaType || 'default',
							agent_engagement_type: opts.agentEngagementType || (isGroup ? 'invoked' : 'direct_chat'),
							mode_selected: opts.modeSelected || '0'
						}
					}
				]
			}

			await relayMessage(jid, message, relayOpts)
			return msgId
		}
	}
}